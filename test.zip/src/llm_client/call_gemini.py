from typing import List, Dict, Optional, Any
import google.generativeai as genai
import json
import os
import re
import sys
import time
import random


def _extract_json(text: str) -> Any:
    """Extract a JSON object/array from a model response.

    Handles fenced blocks and stray prose. Raises ValueError on failure.
    """
    if text is None:
        raise ValueError("Empty response from model.")
    # Try code fences first
    fence = re.search(r"```(?:json)?\n(.*?)\n```", text, re.DOTALL | re.IGNORECASE)
    candidate = fence.group(1) if fence else text
    # Trim leading/trailing non-json
    start = candidate.find("{")
    start_arr = candidate.find("[")
    if start == -1 or (start_arr != -1 and start_arr < start):
        start = start_arr
    if start == -1:
        raise ValueError("No JSON object/array found in response.")
    # Find last closing brace/bracket
    end = max(candidate.rfind("}"), candidate.rfind("]")) + 1
    payload = candidate[start:end]
    return json.loads(payload)


def _retry_sleep(base: float, attempt: int, jitter: bool = True) -> None:
    # Exponential backoff with jitter
    delay = base * (2 ** (attempt - 1))
    if jitter:
        delay = delay * (0.5 + random.random())
    time.sleep(min(delay, 30.0))


def call_gemini(
    model_obj: Any, messages: List[Dict[str, str]], max_retries: int = 3
) -> Any:
    last_err = None
    for attempt in range(1, max_retries + 1):
        try:
            resp = model_obj.generate_content(messages[0]["parts"][0])
            text = resp.text if hasattr(resp, "text") else str(resp)
            return _extract_json(text)
        except Exception as e:  # includes parsing and API errors
            last_err = e
            if attempt == max_retries:
                break
            _retry_sleep(0.7, attempt)
    raise RuntimeError(f"Gemini call failed after {max_retries} attempts: {last_err}")
