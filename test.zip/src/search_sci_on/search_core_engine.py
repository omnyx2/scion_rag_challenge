"""
검색 핵심 엔진 모듈
- 프롬프트 관리
- 키워드 추출 및 검색어 생성
- ScienceON API 검색
"""

import re
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
import google.generativeai as genai

class SearchCoreEngine:
    """검색 핵심 엔진 - 프롬프트, 키워드, 검색 통합"""
    
    def __init__(self, gemini_api_key: str, scienceon_client):
        """
        검색 핵심 엔진 초기화
        
        Args:
            gemini_api_key: Google API 키
            scienceon_client: ScienceON API 클라이언트
        """
        self.gemini_api_key = gemini_api_key
        self.scienceon_client = scienceon_client
        self.model = self._init_gemini()
        
    def _init_gemini(self) -> genai.GenerativeModel:
        """Gemini 모델 초기화"""
        genai.configure(api_key=self.gemini_api_key)
        generation_config = genai.GenerationConfig(
            temperature=0.2,
            candidate_count=1,
        )
        
        return genai.GenerativeModel(
            model_name="gemini-2.5-flash",
            generation_config=generation_config,
        )
    
    def _create_keyword_prompt(self, query: str) -> str:
        """키워드 추출을 위한 프롬프트 생성"""
        return f"""당신은 논문 검색을 위한 키워드 추출 전문가입니다. 주어진 질문에서 ScienceON API 검색에 최적화된 핵심 키워드들을 한국어와 영어로 각각 추출해주세요.

질문: "{query}"

다음 형식으로 키워드를 추출하세요:

1. 한국어 키워드: 3-5개의 핵심 키워드를 쉼표로 구분
2. 영어 키워드: 위 한국어 키워드들의 영어 번역을 쉼표로 구분

규칙:
- 전문용어와 기술용어를 우선적으로 선택
- 축약어, 전체용어를 모두 알 경우, 모두 사용 키워드로 만드세요
- 각 키워드는 1-20자 이내로 간결하게

출력 형식:
한국어: 키워드1, 키워드2, 키워드3, 키워드4
영어: keyword1, keyword2, keyword3, keyword4

키워드:"""
    
    def _create_search_query_prompt(self, query: str, keywords_dict: Dict[str, List[str]]) -> str:
        """검색어 생성을 위한 프롬프트 생성"""
        korean_keywords = keywords_dict.get('korean', [])
        english_keywords = keywords_dict.get('english', [])
        
        return f"""당신은 ScienceON API 검색을 위한 전문가입니다. 주어진 질문과 키워드들을 바탕으로 효과적인 검색어들을 생성해주세요.

질문: "{query}"

한국어 키워드: {', '.join(korean_keywords)}
영어 키워드: {', '.join(english_keywords)}

다음 검색 연산자들을 활용하여 검색어를 생성하세요:
| 연산자: 두 개 이상의 검색어 중 1개 이상을 포함하는 문서를 검색합니다.

중요한 규칙:
- 질문의 핵심 의도와 가장 관련성 높은 검색어를 먼저 생성하세요
- 단순하고 실용적인 검색어를 우선하세요
- 각 키워드를 모두 | 연산자로 연결해서 검색어를 생성하세요
- 최대 12개의 검색어를 생성하세요
- 설명이나 번호 없이 검색어만 나열하세요

검색어 목록:"""
    
    def extract_keywords(self, query: str) -> Dict[str, List[str]]:
        """질문에서 키워드 추출 (한국어, 영어 각각)"""
        try:
            prompt = self._create_keyword_prompt(query)
            response = self.model.generate_content(prompt)
            response_text = response.text.strip()
            
            # "키워드:" 텍스트 제거
            if response_text.startswith("키워드:"):
                response_text = response_text[4:].strip()
            
            # 한국어와 영어 키워드 분리
            korean_keywords = []
            english_keywords = []
            
            lines = response_text.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('한국어:'):
                    korean_text = line.replace('한국어:', '').strip()
                    korean_keywords = [kw.strip() for kw in korean_text.split(',') if kw.strip()]
                elif line.startswith('영어:'):
                    english_text = line.replace('영어:', '').strip()
                    english_keywords = [kw.strip() for kw in english_text.split(',') if kw.strip()]
            
            # 빈 키워드 제거 및 길이 제한
            korean_keywords = [kw for kw in korean_keywords if kw and 1 < len(kw) <= 30]
            english_keywords = [kw for kw in english_keywords if kw and 1 < len(kw) <= 30]

            result = {
                'korean': korean_keywords,
                'english': english_keywords
            }
            
            logging.info(f"질문: {query}")
            logging.info(f"한국어 키워드: {korean_keywords}")
            logging.info(f"영어 키워드: {english_keywords}")
            
            return result
            
        except Exception as e:
            logging.error(f"키워드 추출 실패: {e}")
            return {'korean': [], 'english': []}
    
    def generate_search_queries(self, query: str, keywords_dict: Dict[str, List[str]]) -> List[str]:
        """Gemini를 활용하여 지능적인 검색어 생성"""
        try:
            prompt = self._create_search_query_prompt(query, keywords_dict)
            response = self.model.generate_content(prompt)
            response_text = response.text.strip()
            
            # 검색어 파싱
            search_queries = []
            lines = response_text.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # 설명적인 텍스트나 빈 줄 제외
                if (not line or 
                    line.startswith('검색어:') or 
                    line.startswith('예:') or
                    line.startswith('다음은') or
                    line.startswith('ScienceON') or
                    line.startswith('규칙:') or
                    line.startswith('질문:') or
                    line.startswith('한국어 키워드:') or
                    line.startswith('영어 키워드:') or
                    len(line) < 3):
                    continue
                
                # 번호나 기호 제거
                clean_line = line
                clean_line = re.sub(r'^\d+\.\s*', '', clean_line)
                
                if clean_line.startswith(('-', '•', '.', '`')):
                    clean_line = clean_line[1:].strip()
                
                clean_line = clean_line.replace('`', '').strip()
                clean_line = clean_line.replace('"', '"').replace('"', '"')
                
                if clean_line and len(clean_line) <= 100 and not clean_line.startswith('다음은'):
                    search_queries.append(clean_line)
            
            # 띄어쓰기를 '|'로 변환
            processed_queries = []
            for query in search_queries:
                if ' ' in query:
                    processed_query = query.replace(' ', '|')
                else:
                    processed_query = query
                
                processed_query = re.sub(r'\|+', '|', processed_query)
                processed_query = processed_query.strip('|')
                processed_queries.append(processed_query)
            
            # 중복 제거
            unique_queries = []
            seen = set()
            for query in processed_queries:
                if query not in seen:
                    unique_queries.append(query)
                    seen.add(query)
            
            logging.info(f"Gemini가 생성한 검색어: {unique_queries}")
            return unique_queries[:8]  # 최대 8개로 제한
            
        except Exception as e:
            logging.error(f"검색어 생성 실패: {e}")
            # 실패 시 기본 키워드들 반환
            korean_keywords = keywords_dict.get('korean', [])
            english_keywords = keywords_dict.get('english', [])
            return korean_keywords + english_keywords
    
    def search_documents(self, search_queries: List[str], min_documents: int = 50) -> List[Dict]:
        """검색어로 문서 검색"""
        all_documents = []
        page = 1
        max_pages = 3  # 최대 3페이지까지 검색
        
        while page <= max_pages:
            logging.info(f"페이지 {page} 검색 중... (현재 {len(all_documents)}개 문서)")
            
            # 모든 검색어로 검색
            for search_query in search_queries:
                # 검색어를 API에 전달할 때 따옴표 처리
                api_query = self._prepare_search_query_for_api(search_query)
                docs = self.scienceon_client.search_articles(api_query, cur_page=page, row_count=20)
                
                # 즉시 품질 필터링 적용 (abstract 15자 이하 제외)
                filtered_docs = []
                for doc in docs:
                    abstract = doc.get('abstract', '')
                    if len(abstract.strip()) > 15:  # 15자 이하는 제외
                        filtered_docs.append(doc)
                
                all_documents.extend(filtered_docs)
                
                # 품질 필터링 로그
                filtered_count = len(docs) - len(filtered_docs)
                if filtered_count > 0:
                    logging.info(f"검색어 '{search_query}' → {len(docs)}개 문서 (품질 필터링으로 {filtered_count}개 제외)")
                else:
                    logging.info(f"검색어 '{search_query}' → {len(docs)}개 문서")
                
                # 중복 제거 후 개수 확인
                unique_docs_temp = []
                seen_titles_temp = set()
                for doc in all_documents:
                    title = doc.get('title', '')
                    if title and title not in seen_titles_temp:
                        unique_docs_temp.append(doc)
                        seen_titles_temp.add(title)
                
                if len(unique_docs_temp) >= min_documents:
                    logging.info(f"목표 문서 수 {min_documents}개 달성: {len(unique_docs_temp)}개 (품질 필터링 적용)")
                    break
            
            # 중복 제거 후 개수 확인
            unique_docs_temp = []
            seen_titles_temp = set()
            for doc in all_documents:
                title = doc.get('title', '')
                if title and title not in seen_titles_temp:
                    unique_docs_temp.append(doc)
                    seen_titles_temp.add(title)
            
            if len(unique_docs_temp) >= min_documents:
                break
                
            page += 1
        
        return all_documents
    
    def _prepare_search_query_for_api(self, search_query: str) -> str:
        """검색어를 ScienceON API에 전달하기 위해 준비"""
        # JSON에서 이스케이프된 따옴표를 원래 따옴표로 복원
        api_query = search_query.replace('\\"', '"')
        
        # 백슬래시가 포함된 경우 제거
        api_query = api_query.replace('\\', '')
        
        return api_query
    
    def remove_duplicates_and_filter(self, all_documents: List[Dict]) -> List[Dict]:
        """중복 제거 및 품질 필터링"""
        unique_docs = []
        seen_titles = set()
        
        for doc in all_documents:
            title = doc.get('title', '')
            
            # 제목이 있고 중복이 아닌 경우
            if title and title not in seen_titles:
                # source 필드 제거 (ScienceON이 자명하므로)
                if 'source' in doc:
                    del doc['source']
                unique_docs.append(doc)
                seen_titles.add(title)
        
        return unique_docs
