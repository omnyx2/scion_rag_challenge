#!/usr/bin/env python3
"""
검색 메타데이터 생성 시스템 (리팩토링 버전)
- 모듈화된 구조로 프롬프트, 키워드, 검색 로직 분리
- 단일 실행과 배치 실행 지원
- 간단한 3개 파일 구조
"""

import os
import json
import logging
import pandas as pd
from typing import List, Dict, Any, Optional, Union
from pathlib import Path
from datetime import datetime

# 모듈 import
from search_core_engine import SearchCoreEngine
from query_processor import QueryProcessor

# 기존 ScienceON API 클라이언트 import
from scienceon_api_example import ScienceONAPIClient

# 로깅 설정
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


class SearchMetaSystem:
    """검색 메타데이터 시스템 - 통합 관리"""

    def __init__(
        self,
        gemini_api_key: str,
        scienceon_credentials_path: str = "./configs/scienceon_api_credentials.json",
    ):
        """
        검색 메타데이터 시스템 초기화

        Args:
            gemini_api_key: Gemini API 키
            scienceon_credentials_path: ScienceON API 자격증명 파일 경로
        """
        self.gemini_api_key = gemini_api_key
        self.scienceon_credentials_path = scienceon_credentials_path

        # ScienceON API 클라이언트 초기화
        self.scienceon_client = ScienceONAPIClient(Path(scienceon_credentials_path))

        # 핵심 검색 엔진 초기화
        self.core_engine = SearchCoreEngine(gemini_api_key, self.scienceon_client)

        # 쿼리 처리기 초기화
        self.query_processor = QueryProcessor(self.core_engine)

        logging.info("SearchMetaSystem 초기화 완료")

    def execute_single(self, query: str, min_documents: int = 50) -> Dict[str, Any]:
        """
        단일 쿼리 실행

        Args:
            query: 검색할 질문
            min_documents: 최소 보장 문서 수

        Returns:
            처리 결과 딕셔너리
        """
        logging.info(f"단일 실행 모드: '{query[:50]}...'")

        try:
            result = self.query_processor.process_single_query(query, min_documents)
            result["execution_mode"] = "single"

            logging.info(
                f"단일 실행 완료: {result['total_documents_found']}개 문서 발견"
            )
            return result

        except Exception as e:
            logging.error(f"단일 실행 실패: {e}")
            return {
                "question": query,
                "error": str(e),
                "execution_mode": "single",
                "search_timestamp": datetime.now().isoformat(),
            }

    def execute_batch(
        self,
        queries: List[str],
        min_documents_per_query: int = 50,
        progress_callback: Optional[callable] = None,
    ) -> Dict[str, Any]:
        """
        배치 쿼리 실행

        Args:
            queries: 처리할 질문 리스트
            min_documents_per_query: 쿼리당 최소 보장 문서 수
            progress_callback: 진행률 콜백 함수

        Returns:
            배치 처리 결과 딕셔너리
        """
        logging.info(f"배치 실행 모드: {len(queries)}개 쿼리")

        try:
            results = self.query_processor.process_batch_queries(
                queries, min_documents_per_query, progress_callback
            )

            # 배치 통계 추가
            batch_stats = self.query_processor.get_batch_statistics(results)

            # 각 결과에 실행 모드 추가
            for result in results:
                result["execution_mode"] = "batch"

            # 전체 배치 결과 구성
            batch_result = {
                "batch_statistics": batch_stats,
                "results": results,
                "execution_mode": "batch",
                "batch_timestamp": datetime.now().isoformat(),
            }

            logging.info(
                f"배치 실행 완료: {batch_stats['successful_queries']}/{batch_stats['total_queries']} 성공"
            )
            return batch_result

        except Exception as e:
            logging.error(f"배치 실행 실패: {e}")
            return {
                "error": str(e),
                "execution_mode": "batch",
                "batch_timestamp": datetime.now().isoformat(),
            }

    def execute_batch_in_chunks(
        self,
        queries: List[str],
        chunk_size: int = 10,
        min_documents_per_query: int = 50,
    ) -> List[Dict[str, Any]]:
        """
        청크 단위 배치 실행 (메모리 효율성)

        Args:
            queries: 처리할 질문 리스트
            chunk_size: 청크 크기
            min_documents_per_query: 쿼리당 최소 보장 문서 수

        Returns:
            처리 결과 리스트
        """
        logging.info(
            f"청크 단위 배치 실행: {len(queries)}개 쿼리, 청크 크기 {chunk_size}"
        )

        try:
            results = self.query_processor.process_queries_in_chunks(
                queries, chunk_size, min_documents_per_query
            )

            # 각 결과에 실행 모드 추가
            for result in results:
                result["execution_mode"] = "batch"

            logging.info(f"청크 단위 배치 실행 완료: {len(results)}개 결과")
            return results

        except Exception as e:
            logging.error(f"청크 단위 배치 실행 실패: {e}")
            return []

    def save_results(
        self,
        results: Union[Dict[str, Any], List[Dict[str, Any]]],
        output_path: str = None,
    ) -> str:
        """
        결과를 JSON 파일로 저장

        Args:
            results: 저장할 결과
            output_path: 출력 파일 경로 (None이면 자동 생성)

        Returns:
            저장된 파일 경로
        """
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"search_meta_results_{timestamp}.json"

        # 결과 타입에 따른 처리
        if isinstance(results, dict):
            if "batch_statistics" in results:
                # 배치 통계가 포함된 결과
                save_data = results
            elif "execution_mode" in results:
                # 단일 결과
                save_data = {
                    "single_result": results,
                    "generation_timestamp": datetime.now().isoformat(),
                }
            else:
                # 일반 딕셔너리
                save_data = results
        elif isinstance(results, list):
            # 배치 결과 리스트
            batch_stats = self.query_processor.get_batch_statistics(results)
            save_data = {
                "batch_statistics": batch_stats,
                "results": results,
                "generation_timestamp": datetime.now().isoformat(),
            }
        else:
            raise ValueError("지원하지 않는 결과 타입입니다.")

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(save_data, f, ensure_ascii=False, indent=2)

        logging.info(f"결과가 {output_path}에 저장되었습니다.")
        return output_path

    def load_queries_from_csv(
        self, csv_path: str, question_column: str = "Question"
    ) -> List[str]:
        """
        CSV 파일에서 질문 로드

        Args:
            csv_path: CSV 파일 경로
            question_column: 질문이 있는 컬럼명

        Returns:
            질문 리스트
        """
        return self.query_processor.load_queries_from_csv(csv_path, question_column)

    def convert_to_csv_format(
        self, json_file_path: str, csv_output_path: str = None
    ) -> str:
        """JSON 결과를 CSV 형식으로 변환"""
        return self.query_processor.convert_to_csv_format(
            json_file_path, csv_output_path
        )

    def convert_to_jsonl_format(
        self, json_file_path: str, jsonl_output_path: str = None
    ) -> str:
        """JSON 결과를 JSONL 형식으로 변환"""
        return self.query_processor.convert_to_jsonl_format(
            json_file_path, jsonl_output_path
        )

    def close(self):
        """리소스 정리"""
        if hasattr(self, "scienceon_client"):
            self.scienceon_client.close_session()
        logging.info("SearchMetaSystem 리소스 정리 완료")


def test_single_execution():
    """단일 실행 테스트"""
    print("🧪 단일 실행 테스트 시작")
    print("=" * 50)

    # API 키 설정
    gemini_api_key = os.environ.get("GOOGLE_API_KEY")
    if not gemini_api_key:
        try:
            with open(
                "./configs/gemini_api_credentials.json", "r", encoding="utf-8"
            ) as f:
                credentials = json.load(f)
                gemini_api_key = credentials.get("api_key")
        except Exception as e:
            print(f"❌ Gemini API 키를 찾을 수 없습니다: {e}")
            return

    if not gemini_api_key:
        print(
            "❌ GOOGLE_API_KEY 환경변수나 configs/gemini_api_credentials.json 파일에 API 키를 설정해주세요."
        )
        return

    # ScienceON API 자격증명 확인
    scienceon_credentials_path = "./configs/scienceon_api_credentials.json"
    if not os.path.exists(scienceon_credentials_path):
        print(
            f"❌ ScienceON API 자격증명 파일을 찾을 수 없습니다: {scienceon_credentials_path}"
        )
        return

    try:
        # 검색 시스템 초기화
        search_system = SearchMetaSystem(gemini_api_key, scienceon_credentials_path)

        # 테스트 질문
        test_query = "AI와 머신러닝의 차이점은 무엇인가요?"

        print(f"🔍 테스트 질문: {test_query}")

        # 단일 실행
        result = search_system.execute_single(test_query, min_documents=20)

        # 결과 출력
        print(f"\n📊 단일 실행 결과:")
        print(f"   질문: {result['question']}")
        print(f"   한국어 키워드: {result['keywords']['korean']}")
        print(f"   영어 키워드: {result['keywords']['english']}")
        print(f"   생성된 검색어: {result.get('search_queries', [])[:3]}...")
        print(f"   찾은 문서 수: {result['total_documents_found']}개")

        if result["documents"]:
            print(f"   첫 번째 문서: {result['documents'][0]['title'][:60]}...")

        # 결과 저장
        output_file = search_system.save_results(result)
        print(f"   결과 파일: {output_file}")

        print("\n✅ 단일 실행 테스트 완료!")

        # 리소스 정리
        search_system.close()

    except Exception as e:
        print(f"❌ 단일 실행 테스트 실패: {e}")
        logging.error(f"단일 실행 테스트 실패: {e}")


def test_batch_execution():
    """배치 실행 테스트"""
    print("🧪 배치 실행 테스트 시작")
    print("=" * 50)

    # API 키 설정
    gemini_api_key = os.environ.get("GOOGLE_API_KEY")
    if not gemini_api_key:
        try:
            with open(
                "./configs/gemini_api_credentials.json", "r", encoding="utf-8"
            ) as f:
                credentials = json.load(f)
                gemini_api_key = credentials.get("api_key")
        except Exception as e:
            print(f"❌ Gemini API 키를 찾을 수 없습니다: {e}")
            return

    if not gemini_api_key:
        print(
            "❌ GOOGLE_API_KEY 환경변수나 configs/gemini_api_credentials.json 파일에 API 키를 설정해주세요."
        )
        return

    # ScienceON API 자격증명 확인
    scienceon_credentials_path = "./configs/scienceon_api_credentials.json"
    if not os.path.exists(scienceon_credentials_path):
        print(
            f"❌ ScienceON API 자격증명 파일을 찾을 수 없습니다: {scienceon_credentials_path}"
        )
        return

    try:
        # 검색 시스템 초기화
        search_system = SearchMetaSystem(gemini_api_key, scienceon_credentials_path)

        # test.csv에서 질문 로드
        if os.path.exists("test.csv"):
            queries = search_system.load_queries_from_csv("test.csv")
            print(f"📄 test.csv에서 {len(queries)}개의 질문을 로드했습니다.")

            # 처음 3개만 테스트
            test_queries = queries[:3]
            print(f"🔍 테스트할 질문: {len(test_queries)}개")

            # 진행률 콜백 함수
            def progress_callback(current, total, current_query):
                print(f"   진행률: {current}/{total} - {current_query[:50]}...")

            # 배치 실행
            batch_result = search_system.execute_batch(
                test_queries,
                min_documents_per_query=20,
                progress_callback=progress_callback,
            )

            # 결과 출력
            stats = batch_result["batch_statistics"]
            print(f"\n📊 배치 실행 결과:")
            print(f"   총 처리된 질문: {stats['total_queries']}개")
            print(f"   성공한 질문: {stats['successful_queries']}개")
            print(f"   실패한 질문: {stats['failed_queries']}개")
            print(f"   성공률: {stats['success_rate']:.1f}%")
            print(f"   총 찾은 문서: {stats['total_documents_found']}개")
            print(f"   평균 문서/질문: {stats['avg_documents_per_query']}개")

            # 결과 저장
            output_file = search_system.save_results(batch_result)
            print(f"   결과 파일: {output_file}")

            # 자동으로 CSV와 JSONL 변환 실행
            if batch_result["results"]:
                print(f"\n🔄 자동으로 CSV 변환을 시작합니다...")
                csv_file = search_system.convert_to_csv_format(output_file)
                print(f"🔄 자동으로 JSONL 변환을 시작합니다...")
                jsonl_file = search_system.convert_to_jsonl_format(output_file)

            print("\n✅ 배치 실행 테스트 완료!")

        else:
            print("❌ test.csv 파일을 찾을 수 없습니다.")

        # 리소스 정리
        search_system.close()

    except Exception as e:
        print(f"❌ 배치 실행 테스트 실패: {e}")
        logging.error(f"배치 실행 테스트 실패: {e}")


def test_csv_conversion():
    """CSV 변환 테스트"""
    print("🧪 CSV 변환 테스트 시작")
    print("=" * 40)

    json_files = [
        f
        for f in os.listdir(".")
        if f.startswith("search_meta_results_") and f.endswith(".json")
    ]
    if not json_files:
        print("❌ 변환할 JSON 파일이 없습니다. 먼저 검색을 실행해주세요.")
        return

    latest_json = max(json_files, key=os.path.getctime)
    print(f"📄 변환할 JSON 파일: {latest_json}")

    try:
        # 검색 시스템 초기화 (변환만 하므로 API 키는 임시로 설정)
        search_system = SearchMetaSystem(
            "dummy_key", "./configs/scienceon_api_credentials.json"
        )

        csv_file = search_system.convert_to_csv_format(latest_json)
        if csv_file:
            print(f"✅ CSV 변환 완료: {csv_file}")

        jsonl_file = search_system.convert_to_jsonl_format(latest_json)
        if jsonl_file:
            print(f"✅ JSONL 변환 완료: {jsonl_file}")

        print(f"\n✅ 변환 테스트 완료!")

    except Exception as e:
        print(f"❌ 변환 테스트 실패: {e}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        if sys.argv[1] == "single":
            test_single_execution()
        elif sys.argv[1] == "batch":
            test_batch_execution()
        elif sys.argv[1] == "convert":
            test_csv_conversion()
        else:
            print("사용법: python search_meta_refactored.py [single|batch|convert]")
            print("  single:   단일 실행 테스트")
            print("  batch:    배치 실행 테스트")
            print("  convert:  JSON 결과를 CSV/JSONL로 변환")
    else:
        print("사용법: python search_meta_refactored.py [single|batch|convert]")
        print("  single:   단일 실행 테스트")
        print("  batch:    배치 실행 테스트")
        print("  convert:  JSON 결과를 CSV/JSONL로 변환")
