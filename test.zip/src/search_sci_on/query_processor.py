"""
쿼리 처리기 모듈
- 단일 쿼리 처리
- 배치 쿼리 처리
- 결과 저장 및 통계
"""

import json
import logging
import pandas as pd
from typing import List, Dict, Any, Optional, Union
from datetime import datetime
from .search_core_engine import SearchCoreEngine

class QueryProcessor:
    """쿼리 처리기 - 단일/배치 처리 통합"""
    
    def __init__(self, core_engine: SearchCoreEngine):
        """
        쿼리 처리기 초기화
        
        Args:
            core_engine: 검색 핵심 엔진
        """
        self.core_engine = core_engine
    
    def process_single_query(self, query: str, min_documents: int = 50) -> Dict[str, Any]:
        """
        단일 쿼리 처리: 키워드 추출 + 문서 검색
        
        Args:
            query: 검색할 질문
            min_documents: 최소 보장 문서 수 (기본 50개)
            
        Returns:
            처리 결과 딕셔너리
        """
        logging.info(f"질문 처리 시작: {query[:50]}...")
        
        try:
            # 1. 키워드 추출
            keywords_dict = self.core_engine.extract_keywords(query)
            korean_keywords = keywords_dict.get('korean', [])
            english_keywords = keywords_dict.get('english', [])
            
            # 2. 검색어 생성 (Gemini 활용)
            search_queries = self.core_engine.generate_search_queries(query, keywords_dict)
            logging.info(f"생성된 검색어 {len(search_queries)}개: {search_queries[:5]}...")
            
            # 3. 질문 언어 감지
            is_english_query = any(char.isascii() and char.isalpha() for char in query[:50])
            
            if is_english_query:
                logging.info(f"영어 질문 감지: 영어 우선 검색어 사용")
            else:
                logging.info(f"한국어 질문 감지: 한국어 우선 검색어 사용")
            
            # 4. 검색어로 문서 검색
            all_documents = self.core_engine.search_documents(search_queries, min_documents)
            
            # 5. 중복 제거 및 품질 필터링
            unique_docs = self.core_engine.remove_duplicates_and_filter(all_documents)
            
            # 6. 결과 정리
            result = {
                'question': query,
                'keywords': {
                    'korean': korean_keywords,
                    'english': english_keywords
                },
                'search_queries': search_queries,
                'documents': unique_docs,
                'total_documents_found': len(unique_docs),
                'search_timestamp': datetime.now().isoformat()
            }
            
            total_keywords = len(korean_keywords) + len(english_keywords)
            logging.info(f"질문 처리 완료: {total_keywords}개 키워드 → {len(search_queries)}개 검색어 → {len(unique_docs)}개 문서")
            
            return result
            
        except Exception as e:
            logging.error(f"단일 쿼리 처리 실패: {e}")
            return {
                'question': query,
                'keywords': {'korean': [], 'english': []},
                'search_queries': [],
                'documents': [],
                'total_documents_found': 0,
                'error': str(e),
                'search_timestamp': datetime.now().isoformat()
            }
    
    def process_batch_queries(self, queries: List[str], min_documents_per_query: int = 50, 
                            progress_callback: Optional[callable] = None) -> List[Dict[str, Any]]:
        """
        여러 쿼리 일괄 처리
        
        Args:
            queries: 처리할 질문 리스트
            min_documents_per_query: 쿼리당 최소 보장 문서 수 (기본 50개)
            progress_callback: 진행률 콜백 함수 (current, total, current_query) -> None
            
        Returns:
            처리 결과 리스트
        """
        results = []
        total_queries = len(queries)
        
        logging.info(f"배치 처리 시작: {total_queries}개 쿼리")
        
        for i, query in enumerate(queries, 1):
            # 진행률 콜백 호출
            if progress_callback:
                progress_callback(i, total_queries, query)
            
            logging.info(f"진행률: {i}/{total_queries}")
            try:
                result = self.process_single_query(query, min_documents_per_query)
                results.append(result)
            except Exception as e:
                logging.error(f"쿼리 처리 실패: {query[:50]}... - {e}")
                # 실패한 쿼리도 결과에 포함
                results.append({
                    'question': query,
                    'keywords': {'korean': [], 'english': []},
                    'search_queries': [],
                    'documents': [],
                    'total_documents_found': 0,
                    'error': str(e),
                    'search_timestamp': datetime.now().isoformat()
                })
        
        logging.info(f"배치 처리 완료: {total_queries}개 쿼리 처리됨")
        return results
    
    def process_queries_in_chunks(self, queries: List[str], chunk_size: int = 10, 
                                min_documents_per_query: int = 50) -> List[Dict[str, Any]]:
        """
        청크 단위로 쿼리 처리 (메모리 효율성)
        
        Args:
            queries: 처리할 질문 리스트
            chunk_size: 청크 크기
            min_documents_per_query: 쿼리당 최소 보장 문서 수
            
        Returns:
            처리 결과 리스트
        """
        all_results = []
        total_queries = len(queries)
        total_chunks = (total_queries + chunk_size - 1) // chunk_size
        
        logging.info(f"청크 단위 배치 처리 시작: {total_queries}개 쿼리, {total_chunks}개 청크")
        
        for chunk_idx in range(total_chunks):
            start_idx = chunk_idx * chunk_size
            end_idx = min(start_idx + chunk_size, total_queries)
            chunk_queries = queries[start_idx:end_idx]
            
            logging.info(f"청크 {chunk_idx + 1}/{total_chunks} 처리 중: {len(chunk_queries)}개 쿼리")
            
            chunk_results = self.process_batch_queries(chunk_queries, min_documents_per_query)
            all_results.extend(chunk_results)
            
            logging.info(f"청크 {chunk_idx + 1} 완료: {len(chunk_results)}개 결과")
        
        logging.info(f"청크 단위 배치 처리 완료: {len(all_results)}개 결과")
        return all_results
    
    def get_batch_statistics(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        배치 처리 통계 정보 반환
        
        Args:
            results: 배치 처리 결과
            
        Returns:
            통계 정보 딕셔너리
        """
        total_queries = len(results)
        successful_queries = len([r for r in results if 'error' not in r])
        failed_queries = total_queries - successful_queries
        total_documents = sum(r.get('total_documents_found', 0) for r in results)
        
        # 키워드 통계
        total_korean_keywords = sum(len(r.get('keywords', {}).get('korean', [])) for r in results)
        total_english_keywords = sum(len(r.get('keywords', {}).get('english', [])) for r in results)
        
        # 검색어 통계
        total_search_queries = sum(len(r.get('search_queries', [])) for r in results)
        
        # 평균 계산
        avg_documents_per_query = total_documents / total_queries if total_queries > 0 else 0
        avg_korean_keywords = total_korean_keywords / total_queries if total_queries > 0 else 0
        avg_english_keywords = total_english_keywords / total_queries if total_queries > 0 else 0
        avg_search_queries = total_search_queries / total_queries if total_queries > 0 else 0
        
        return {
            'total_queries': total_queries,
            'successful_queries': successful_queries,
            'failed_queries': failed_queries,
            'success_rate': (successful_queries / total_queries * 100) if total_queries > 0 else 0,
            'total_documents_found': total_documents,
            'avg_documents_per_query': round(avg_documents_per_query, 2),
            'total_korean_keywords': total_korean_keywords,
            'total_english_keywords': total_english_keywords,
            'avg_korean_keywords_per_query': round(avg_korean_keywords, 2),
            'avg_english_keywords_per_query': round(avg_english_keywords, 2),
            'total_search_queries_generated': total_search_queries,
            'avg_search_queries_per_query': round(avg_search_queries, 2),
            'processing_timestamp': datetime.now().isoformat()
        }
    
    def save_results(self, results: Union[Dict[str, Any], List[Dict[str, Any]]], 
                    output_path: str = None) -> str:
        """
        결과를 JSON 파일로 저장
        
        Args:
            results: 저장할 결과 (단일 결과 또는 배치 결과)
            output_path: 출력 파일 경로 (None이면 자동 생성)
            
        Returns:
            저장된 파일 경로
        """
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"search_meta_results_{timestamp}.json"
        
        # 결과 타입에 따른 처리
        if isinstance(results, dict):
            # 단일 결과
            save_data = {
                'single_result': results,
                'generation_timestamp': datetime.now().isoformat()
            }
        elif isinstance(results, list):
            # 배치 결과 리스트
            batch_stats = self.get_batch_statistics(results)
            save_data = {
                'batch_statistics': batch_stats,
                'results': results,
                'generation_timestamp': datetime.now().isoformat()
            }
        else:
            raise ValueError("지원하지 않는 결과 타입입니다.")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(save_data, f, ensure_ascii=False, indent=2)
        
        logging.info(f"결과가 {output_path}에 저장되었습니다.")
        return output_path
    
    def load_queries_from_csv(self, csv_path: str, question_column: str = 'Question') -> List[str]:
        """
        CSV 파일에서 질문 로드
        
        Args:
            csv_path: CSV 파일 경로
            question_column: 질문이 있는 컬럼명
            
        Returns:
            질문 리스트
        """
        try:
            df = pd.read_csv(csv_path)
            
            if question_column not in df.columns:
                raise ValueError(f"컬럼 '{question_column}'을 찾을 수 없습니다. 사용 가능한 컬럼: {list(df.columns)}")
            
            queries = df[question_column].dropna().tolist()
            logging.info(f"CSV에서 {len(queries)}개의 질문을 로드했습니다: {csv_path}")
            
            return queries
            
        except Exception as e:
            logging.error(f"CSV 로드 실패: {e}")
            return []
    
    def convert_to_csv_format(self, json_file_path: str, csv_output_path: str = None) -> str:
        """JSON 결과를 CSV 형식으로 변환 (Title, Abstract, Source 포함)"""
        logging.info("🔄 JSON 결과를 CSV 형식으로 변환 중...")
        
        try:
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            logging.error(f"JSON 파일 로드 실패: {e}")
            return ""
        
        if csv_output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            csv_output_path = f"search_results_{timestamp}.csv"
        
        # 단일 결과인지 배치 결과인지 확인
        if 'single_result' in data:
            single_result = data['single_result']
            if 'results' in single_result:
                # 배치 결과가 single_result 안에 있는 경우
                results = single_result['results']
            else:
                # 진짜 단일 결과인 경우
                results = [single_result]
        elif 'results' in data:
            results = data['results']
        else:
            logging.error("올바른 JSON 형식이 아닙니다.")
            return ""
        
        csv_data = []
        for result in results:
            row_data = {'Question': result['question']}
            
            for i in range(1, 51):
                if i <= len(result['documents']):
                    doc = result['documents'][i-1]
                    title = doc.get('title', '제목 없음')
                    abstract = doc.get('abstract', '초록 없음')
                    cn = doc.get('CN', '')
                    source_url = f"http://click.ndsl.kr/servlet/OpenAPIDetailView?keyValue={cn}&target=NART&cn={cn}" if cn else "Source 정보 없음"
                    article_info = f"Title: {title}, Abstract: {abstract}, Source: {source_url}"
                    row_data[f'Prediction_retrieved_article_name_{i}'] = article_info
                else:
                    row_data[f'Prediction_retrieved_article_name_{i}'] = ''
            
            csv_data.append(row_data)
        
        try:
            df = pd.DataFrame(csv_data)
            df.to_csv(csv_output_path, index=False, encoding='utf-8')
            logging.info(f"✅ CSV 파일 생성 완료: {csv_output_path}")
            logging.info(f"   총 {len(csv_data)}개 질문, 각각 최대 50개 논문 정보 포함")
            
            return csv_output_path
            
        except Exception as e:
            logging.error(f"CSV 파일 저장 실패: {e}")
            return ""
    
    def convert_to_jsonl_format(self, json_file_path: str, jsonl_output_path: str = None) -> str:
        """JSON 결과를 JSONL 형식으로 변환 (중복 없는 논문 목록)"""
        logging.info("🔄 JSON 결과를 JSONL 형식으로 변환 중...")
        
        try:
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            logging.error(f"JSON 파일 로드 실패: {e}")
            return ""
        
        if jsonl_output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            jsonl_output_path = f"search_documents_{timestamp}.jsonl"
        
        # 단일 결과인지 배치 결과인지 확인
        if 'single_result' in data:
            single_result = data['single_result']
            if 'results' in single_result:
                # 배치 결과가 single_result 안에 있는 경우
                results = single_result['results']
            else:
                # 진짜 단일 결과인 경우
                results = [single_result]
        elif 'results' in data:
            results = data['results']
        else:
            logging.error("올바른 JSON 형식이 아닙니다.")
            return ""
        
        # 중복 제거를 위한 set (CN 기준)
        seen_cns = set()
        unique_documents = []
        
        for result in results:
            for doc in result['documents']:
                cn = doc.get('CN', '')
                if cn and cn not in seen_cns:
                    seen_cns.add(cn)
                    # JSONL 형식으로 변환
                    jsonl_doc = {
                        "CN": cn,
                        "title": doc.get('title', ''),
                        "abstract": doc.get('abstract', ''),
                        "source": f"http://click.ndsl.kr/servlet/OpenAPIDetailView?keyValue={cn}&target=NART&cn={cn}"
                    }
                    unique_documents.append(jsonl_doc)
        
        # JSONL 파일로 저장
        try:
            with open(jsonl_output_path, 'w', encoding='utf-8') as f:
                for doc in unique_documents:
                    f.write(json.dumps(doc, ensure_ascii=False) + '\n')
            
            logging.info(f"✅ JSONL 파일 생성 완료: {jsonl_output_path}")
            logging.info(f"   총 {len(unique_documents)}개 중복 없는 논문")
            
            return jsonl_output_path
            
        except Exception as e:
            logging.error(f"JSONL 파일 저장 실패: {e}")
            return ""
