import os
import json
import csv
import jsonlines
from datetime import datetime
from sentence_transformers import SentenceTransformer
from utils.load_json import load_json as load_config
from utils.load_jsonl_and_make_text_for_embedding import (
    load_jsonl_and_make_text_for_embedding as load_jsonl_docs,
)


def save_as_csv_with_metadata(documents_data, embeddings, output_file):
    """
    임베딩 벡터와 원본 데이터 정보를 함께 CSV로 저장
    """
    with open(output_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)

        # 헤더 작성
        writer.writerow(
            [
                "CN",
                "title",
                "abstract",
                "source",
                "embedding_mode",
                "embedding_text",
                "embedding",
            ]
        )

        # 데이터 작성
        for doc_data, emb in zip(documents_data, embeddings):
            writer.writerow(
                [
                    doc_data["cn"],
                    doc_data["title"],
                    doc_data["abstract"],
                    doc_data["source"],
                    doc_data["embedding_mode"],
                    doc_data["embedding_text"],
                    emb.tolist(),
                ]
            )


def main(config_path="../configs/query_encoder/config_PwC-Embedding_expr.json"):
    # 1. 설정 로드
    config = load_config(config_path)

    # 2. JSONL 파일 경로 설정
    jsonl_path = config.get(
        "jsonl_path",
        "../results/searched_docs_db/search_documents_20250908_220551.jsonl",
    )  # JSONL 파일 경로

    # 3. 데이터 로드
    print(f"Loading documents from {jsonl_path}")
    documents_data = load_jsonl_docs(jsonl_path)
    print(f"Loaded {len(documents_data)} documents")

    if len(documents_data) == 0:
        print("No documents found to embed.")
        return

    # 4. 모델 로드
    model_name = config["model_name"]
    print(f"Loading model: {model_name}")
    model = SentenceTransformer(model_name, trust_remote_code=True)

    # 5. 임베딩 텍스트 추출
    texts_to_embed = [doc["embedding_text"] for doc in documents_data]

    # 6. 임베딩 생성
    print("Encoding documents...")
    embeddings = model.encode(
        texts_to_embed, convert_to_numpy=True, show_progress_bar=True
    )

    # 7. 저장 경로 생성
    timestamp = datetime.now().strftime("%y%m%d_%H%M%S")
    safe_model_name = model_name.replace("/", "_")
    output_dir = os.path.join(config.get("output_dir", "../output"), timestamp)
    os.makedirs(output_dir, exist_ok=True)

    # 8. 파일명 생성
    output_file = os.path.join(
        output_dir, f"vector_db_{config.get('nickname', 'docs')}_{safe_model_name}.csv"
    )

    # 9. CSV로 저장 (임베딩 벡터 + 원본 데이터 정보)
    save_as_csv_with_metadata(documents_data, embeddings, output_file)

    # 10. 결과 출력
    print(f"✅ VectorDB saved to {output_file}")
    print(f"✅ Embedding mode: 3*title+abstract")
    print(f"✅ Total documents embedded: {len(documents_data)}")
    print(f"✅ Embedding dimension: {embeddings.shape[1]}")

    # 11. config 업데이트 (선택사항)
    config["output_file"] = output_file
    config["jsonl_path"] = jsonl_path
    config["embedding_mode"] = "3*title+abstract"
    config["last_run"] = timestamp

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

    print(f"✅ Config updated at {config_path}")


if __name__ == "__main__":
    # config 파일 경로를 실제 경로로 수정하세요
    main()
